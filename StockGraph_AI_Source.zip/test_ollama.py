
import ollama

print("STOCKGRAPH AI - CONNECTION TEST")

try:
    print("\nTesting Qwen...")

    response = ollama.chat(
        model="qwen2.5:3b",
        messages=[
            {
                "role": "user",
                "content": "Explain stock market analysis in three simple sentences."
            }
        ]
    )

    print("\nQWEN RESPONSE:")
    print(response["message"]["content"])

    print("\nTesting Nomic embeddings...")

    result = ollama.embed(
        model="nomic-embed-text",
        input="Reliance Industries financial performance"
    )

    print("Embedding dimensions:",
          len(result["embeddings"][0]))

    print("\nSUCCESS: Both models are working!")

except Exception as error:
    print("\nERROR:", repr(error))
