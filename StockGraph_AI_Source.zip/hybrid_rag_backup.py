
import ollama

from config import LLM_MODEL, OLLAMA_BASE_URL
from hybrid_retrieval import run_hybrid_search
from rag_evaluation import validate_citations


# Initialize Ollama client
client = ollama.Client(host=OLLAMA_BASE_URL)


SYSTEM_PROMPT = """
You are StockGraph AI, a financial research assistant.

Answer questions using ONLY the supplied retrieved evidence.

STRICT RULES:

1. Never invent financial figures, facts, relationships, or events.
2. Carefully identify the company or subsidiary mentioned in the evidence.
3. Do not confuse Reliance Retail Ventures Limited with Reliance Industries Limited.
4. If the requested financial metric is present in the evidence, answer directly.
5. Distinguish Revenue, Profit Before Tax, and Profit After Tax.
6. Preserve the financial year and units exactly.
7. If the requested metric is absent, clearly state that the evidence is insufficient.
8. Cite every factual financial claim using this exact format:
   (Source: filename.pdf, Page: 10)
9. Place citations next to the relevant claims.
10. Do not use outside knowledge.
11. Do not refuse when the evidence directly contains the answer.
12. Never treat a citation as proof that an unsupported claim is correct.
"""


def build_prompt(question, context):

    return f"""
{SYSTEM_PROMPT}

USER QUESTION:
{question}

RETRIEVED EVIDENCE:
{context}

INSTRUCTIONS:
Answer the question using the retrieved evidence.

Include source filename and page number for factual claims.
If evidence directly answers the question, provide the answer.

ANSWER:
"""


def answer_question(question, top_k=5):

    # Validate question
    if not question or not question.strip():
        return {
            "answer": "Please enter a valid question.",
            "sources": [],
            "retrieval": None,
            "citation_report": None
        }

    print("\nSearching documents and Knowledge Graph...")

    # Retrieve documents and graph evidence
    results, context = run_hybrid_search(
        question,
        top_k=top_k
    )

    vector_results = results["vector_results"]
    graph_results = results["graph_results"]

    # Stop if no evidence was retrieved
    if not vector_results and not graph_results["relationships"]:
        return {
            "answer": (
                "I could not find relevant evidence in the "
                "available documents or Knowledge Graph."
            ),
            "sources": [],
            "retrieval": results,
            "citation_report": None
        }

    # Display retrieved context
    print("\n========== DEBUG: RETRIEVED CONTEXT ==========")
    print(context)
    print("\n========== END OF CONTEXT ==========")

    # Build prompt
    prompt = build_prompt(question, context)

    print("\nGenerating answer with Ollama...")

    # Generate answer
    response = client.generate(
        model=LLM_MODEL,
        prompt=prompt,
        options={
            "temperature": 0
        }
    )

    answer = response["response"].strip()

    # Collect sources supplied to the model
    sources = set()

    for item in vector_results:
        sources.add((
            str(item["source"]),
            str(item["page"])
        ))

    for item in graph_results["relationships"]:
        sources.add((
            str(item["source"]),
            str(item["page"])
        ))

    # Validate citations AFTER collecting sources
    citation_report = validate_citations(
        answer,
        sources
    )

    print("\n========== CITATION VALIDATION ==========")

    print(
        "Total citations:",
        citation_report["total_citations"]
    )

    print(
        "Valid citations:",
        len(citation_report["valid_citations"])
    )

    print(
        "Invalid citations:",
        len(citation_report["invalid_citations"])
    )

    if citation_report["all_citations_valid"]:
        print("Citation status: PASSED")
    else:
        print("Citation status: FAILED")

    if citation_report["invalid_citations"]:
        print("Invalid citation details:")
        print(citation_report["invalid_citations"])

    print("=========================================")

    # Return complete result
    return {
        "answer": answer,
        "sources": sorted(sources),
        "retrieval": results,
        "citation_report": citation_report
    }


# Main program
if __name__ == "__main__":

    print("=" * 60)
    print("STOCKGRAPH AI - HYBRID RAG ASSISTANT")
    print("=" * 60)

    question = input("\nAsk a question: ").strip()

    result = answer_question(question)

    print("\n" + "=" * 60)
    print("AI ANSWER")
    print("=" * 60)

    print(result["answer"])

    print("\n" + "=" * 60)
    print("RETRIEVED SOURCES")
    print("=" * 60)

    for source, page in result["sources"]:
        print(f"{source} | Page {page}")

    print("\n" + "=" * 60)
    print("FINAL EVALUATION")
    print("=" * 60)

    if result["citation_report"] is not None:

        report = result["citation_report"]

        print("Citation count:", report["total_citations"])
        print("Valid:", len(report["valid_citations"]))
        print("Invalid:", len(report["invalid_citations"]))
        print("All citations valid:", report["all_citations_valid"])

    else:
        print("Citation validation was not performed.")

    print("\n" + "=" * 60)
    print("COMPLETED")
    print("=" * 60)
