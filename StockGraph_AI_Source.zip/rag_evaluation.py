
import re


def normalize_text(text):
    """Normalize text for matching."""
    return re.sub(r"\s+", " ", str(text)).strip()


def extract_citations(answer):
    """Extract citations in same-line and separate-line formats."""

    patterns = [
        # Format: (Source: r2.pdf, Page: 145)
        (
            r"\*{0,2}Source:\*{0,2}\s*([^,\n]+),\s*"
            r"\*{0,2}Page:\*{0,2}\s*(\d+)"
        ),

        # Format:
        # - **Source:** r2.pdf
        # - **Page:** 145
        (
            r"\*{0,2}Source:\*{0,2}\s*([^\n]+)\n"
            r"\s*[-*]?\s*\*{0,2}Page:\*{0,2}\s*(\d+)"
        )
    ]

    matches = []

    for pattern in patterns:
        matches.extend(
            re.findall(pattern, answer, re.IGNORECASE)
        )

    citations = []
    seen = set()

    for source, page in matches:
        source = source.strip().strip("*").strip()
        page = page.strip()

        key = (normalize_text(source), page)

        if key not in seen:
            citations.append({
                "source": source,
                "page": page
            })
            seen.add(key)

    return citations


def validate_citations(answer, retrieved_sources):
    """Check citation membership, not factual correctness."""

    citations = extract_citations(answer)

    available_sources = {
        (normalize_text(source), str(page).strip())
        for source, page in retrieved_sources
    }

    valid = []
    invalid = []

    for citation in citations:
        key = (
            normalize_text(citation["source"]),
            citation["page"]
        )

        if key in available_sources:
            valid.append(citation)
        else:
            invalid.append(citation)

    return {
        "total_citations": len(citations),
        "valid_citations": valid,
        "invalid_citations": invalid,
        "has_citations": len(citations) > 0,
        "all_citations_valid": (
            len(citations) > 0 and len(invalid) == 0
        )
    }


def evaluate_rag_result(result):
    """Evaluate basic RAG output."""

    answer = result.get("answer", "")
    sources = result.get("sources", [])

    citation_result = validate_citations(answer, sources)

    return {
        "answer_present": bool(answer.strip()),
        "source_count": len(sources),
        "citation_validation": citation_result
    }


def check_claim_support(claims, evidence):
    """
    Exact phrase matching.
    This does not establish semantic or factual correctness.
    """

    normalized_evidence = normalize_text(evidence).casefold()

    supported = []
    unsupported = []

    for claim in claims:
        normalized_claim = normalize_text(claim).casefold()

        if normalized_claim and normalized_claim in normalized_evidence:
            supported.append(claim)
        else:
            unsupported.append(claim)

    return {
        "total_claims": len(claims),
        "supported_claims": supported,
        "unsupported_claims": unsupported,
        "all_claims_supported": (
            len(claims) > 0 and len(unsupported) == 0
        )
    }
