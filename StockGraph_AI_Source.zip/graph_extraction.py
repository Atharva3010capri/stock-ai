
import json
import hashlib
import re

import ollama

from config import OLLAMA_BASE_URL, LLM_MODEL
from vector_store import search_documents
from knowledge_graph import (
    graph,
    add_entity,
    add_relationship,
    get_graph_statistics,
    save_graph,
    load_graph
)


# --------------------------------------------------
# OLLAMA CLIENT
# --------------------------------------------------

client = ollama.Client(host=OLLAMA_BASE_URL)


# Load previously saved graph when available
load_graph()


# --------------------------------------------------
# HELPER FUNCTIONS
# --------------------------------------------------

def make_entity_id(name):
    """Create a stable ID from an entity name."""

    normalized = name.strip().lower()

    return hashlib.sha256(
        normalized.encode("utf-8")
    ).hexdigest()[:16]


def normalize_text(text):
    """Normalize whitespace for evidence comparison."""

    return re.sub(r"\s+", " ", text).strip()


def parse_json_response(response_text):
    """Parse JSON returned by the LLM."""

    response_text = response_text.strip()

    try:
        return json.loads(response_text)

    except json.JSONDecodeError:

        match = re.search(
            r"\{.*\}",
            response_text,
            re.DOTALL
        )

        if not match:
            raise ValueError(
                "The model did not return valid JSON."
            )

        return json.loads(match.group())


# --------------------------------------------------
# EXTRACT ENTITIES AND RELATIONSHIPS
# --------------------------------------------------

def extract_from_chunk(chunk):
    """
    Extract entities and relationships from one
    retrieved document chunk.

    Relationship evidence must match the original
    document passage.
    """

    text = chunk["text"]

    metadata = chunk["metadata"]

    source_file = metadata.get(
        "source",
        "unknown"
    )

    page = metadata.get(
        "page",
        "unknown"
    )

    prompt = f"""
You are an information extraction system.

Extract entities and relationships from the
financial document passage below.

STRICT RULES:

1. Extract only entities explicitly mentioned.
2. Extract only relationships explicitly supported.
3. Do not use outside knowledge.
4. Do not invent company relationships.
5. Do not invent financial figures.
6. Every relationship must include an exact
   quotation copied from the passage.
7. If there is insufficient evidence, return
   an empty relationships list.
8. Return valid JSON only.

ENTITY TYPES:
company, subsidiary, business_segment, person,
financial_metric, product, location, other

Return this JSON structure:

{{
    "entities": [
        {{
            "name": "Entity name",
            "type": "company"
        }}
    ],
    "relationships": [
        {{
            "source": "Source entity name",
            "target": "Target entity name",
            "relationship": "HAS_BUSINESS_SEGMENT",
            "evidence": "Exact quotation from the passage"
        }}
    ]
}}

DOCUMENT PASSAGE:

{text}
"""

    response = client.generate(
        model=LLM_MODEL,
        prompt=prompt,
        format="json",
        options={
            "temperature": 0
        }
    )

    extracted = parse_json_response(
        response["response"]
    )

    if not isinstance(extracted, dict):
        return {
            "entities_added": 0,
            "relationships_added": 0,
            "rejected_relationships": 0
        }

    entities = extracted.get("entities", [])
    relationships = extracted.get("relationships", [])

    if not isinstance(entities, list):
        entities = []

    if not isinstance(relationships, list):
        relationships = []

    # Map names to stable entity IDs
    entity_ids = {}

    entities_added = 0
    relationships_added = 0
    rejected_relationships = 0

    # --------------------------------------------------
    # ADD ENTITIES
    # --------------------------------------------------

    for entity in entities:

        if not isinstance(entity, dict):
            continue

        name = entity.get("name", "")
        entity_type = entity.get("type", "other")

        if not isinstance(name, str) or not name.strip():
            continue

        if not isinstance(entity_type, str):
            entity_type = "other"

        name = name.strip()

        entity_id = make_entity_id(name)

        if entity_id not in graph:
            add_entity(
                entity_id=entity_id,
                name=name,
                entity_type=entity_type.strip(),
                description=""
            )
            entities_added += 1

        entity_ids[name.lower()] = entity_id

    # --------------------------------------------------
    # VALIDATE AND ADD RELATIONSHIPS
    # --------------------------------------------------

    normalized_passage = normalize_text(text)

    for relation in relationships:

        if not isinstance(relation, dict):
            rejected_relationships += 1
            continue

        source_name = relation.get("source", "")
        target_name = relation.get("target", "")
        relation_type = relation.get("relationship", "")
        evidence = relation.get("evidence", "")

        if not all(
            isinstance(value, str) and value.strip()
            for value in [
                source_name,
                target_name,
                relation_type,
                evidence
            ]
        ):
            rejected_relationships += 1
            continue

        source_id = entity_ids.get(
            source_name.strip().lower()
        )

        target_id = entity_ids.get(
            target_name.strip().lower()
        )

        if not source_id or not target_id:
            rejected_relationships += 1
            continue

        # Evidence must appear in the original passage
        if normalize_text(evidence) not in normalized_passage:
            rejected_relationships += 1
            continue

        add_relationship(
            source_id=source_id,
            target_id=target_id,
            relationship=relation_type.strip(),
            source_file=source_file,
            page=page,
            evidence=evidence.strip()
        )

        relationships_added += 1

    return {
        "entities_added": entities_added,
        "relationships_added": relationships_added,
        "rejected_relationships": rejected_relationships
    }


# --------------------------------------------------
# MAIN GRAPH EXTRACTION FUNCTION
# --------------------------------------------------

def extract_graph(query, top_k=5):
    """
    Retrieve relevant PDF passages, extract entities
    and relationships, validate evidence and save graph.
    """

    if not query or not query.strip():
        raise ValueError("Please provide a search query.")

    print("\nSearching financial documents...")

    results = search_documents(
        query,
        top_k=top_k
    )

    if not results:
        print("No relevant document passages found.")

        return get_graph_statistics()

    totals = {
        "entities_added": 0,
        "relationships_added": 0,
        "rejected_relationships": 0
    }

    for index, chunk in enumerate(results, start=1):

        metadata = chunk["metadata"]

        print(
            f"\nProcessing passage {index}/{len(results)}"
        )

        print(
            f"Source: {metadata.get('source')} "
            f"| Page: {metadata.get('page')}"
        )

        try:

            result = extract_from_chunk(chunk)

            for key in totals:
                totals[key] += result[key]

            print("Extraction result:", result)

        except Exception as error:

            print(
                "Passage extraction failed:",
                str(error)
            )

    # Save graph after processing
    saved_path = save_graph()

    statistics = get_graph_statistics()

    print("\nExtraction completed.")
    print("Extraction totals:", totals)
    print("Graph statistics:", statistics)
    print("Saved graph:", saved_path)

    return {
        "extraction": totals,
        "statistics": statistics,
        "saved_path": saved_path
    }


# --------------------------------------------------
# DIRECT EXECUTION TEST
# --------------------------------------------------

if __name__ == "__main__":

    print("=" * 55)
    print("STOCKGRAPH AI - GRAPH EXTRACTION")
    print("=" * 55)

    print(
        "Knowledge Graph extraction module loaded."
    )
