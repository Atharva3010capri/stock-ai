
import re

from config import TOP_K_RESULTS
from vector_store import search_documents
from knowledge_graph import graph, load_graph, get_entity


# Load the existing Knowledge Graph.
load_graph()


# --------------------------------------------------
# 1. TEXT PROCESSING
# --------------------------------------------------

STOP_WORDS = {
    "the", "and", "for", "with", "from", "what",
    "which", "when", "where", "who", "how", "why",
    "are", "is", "was", "were", "does", "do", "did",
    "can", "could", "would", "should", "about",
    "their", "this", "that", "these", "those",
    "into", "its", "during", "between", "have",
    "has", "had", "company", "companies"
}


def normalize_word(word):
    """Normalize simple plural forms for matching."""

    word = word.lower()

    if len(word) > 4 and word.endswith("ies"):
        return word[:-3] + "y"

    if len(word) > 4 and word.endswith("s") and not word.endswith("ss"):
        return word[:-1]

    return word


def tokenize(text):
    """Convert text into normalized searchable terms."""

    words = re.findall(r"[a-zA-Z0-9]+", str(text).lower())

    return {
        normalize_word(word)
        for word in words
        if len(word) > 2 and word not in STOP_WORDS
    }


def normalize_text(text):
    """Normalize text for duplicate and overlap detection."""

    return " ".join(
        re.findall(r"[a-zA-Z0-9]+", str(text).lower())
    )


def extract_query_terms(query):
    return tokenize(query)


# --------------------------------------------------
# 2. VECTOR SEARCH
# --------------------------------------------------

def vector_search(query, top_k=TOP_K_RESULTS, ticker=None):
    """Search document chunks, optionally restricted to a stock ticker."""

    where = {"ticker": ticker} if ticker else None

    documents = search_documents(
        query,
        top_k=top_k,
        where=where
    )

    results = []

    for document in documents:
        metadata = document.get("metadata", {})

        results.append({
            "text": document.get("text", ""),
            "source": metadata.get("source", "Unknown"),
            "page": metadata.get("page", "Unknown"),
            "company": metadata.get("company", "Unknown"),
            "ticker": metadata.get("ticker", "Unknown"),
            "distance": document.get("distance"),
            "type": "vector"
        })

    return results
# --------------------------------------------------
# 3. KNOWLEDGE GRAPH SEARCH
# --------------------------------------------------


def graph_search(query, top_k=TOP_K_RESULTS):

    query_terms = extract_query_terms(query)

    if not query_terms:
        return {
            "entities": [],
            "relationships": []
        }

    matched_entities = set()
    relationship_matches = []

    for entity_id, data in graph.nodes(data=True):

        entity_terms = tokenize(
            f"{data.get('name', '')} {data.get('description', '')}"
        )

        if query_terms.intersection(entity_terms):
            matched_entities.add(entity_id)

    for source, target, edge_data in graph.edges(data=True):

        source_name = graph.nodes[source].get("name", "")
        target_name = graph.nodes[target].get("name", "")

        relationship = edge_data.get("relationship", "")
        evidence = edge_data.get("evidence", "")

        source_terms = tokenize(source_name)
        target_terms = tokenize(target_name)
        relationship_terms = tokenize(relationship)
        evidence_terms = tokenize(evidence)

        # Remove source-company terms from evidence matching.
        # A company-name match alone must not qualify a relationship.
        relevant_evidence_terms = evidence_terms - source_terms

        relationship_terms_matched = (
            query_terms.intersection(relationship_terms)
        )

        target_terms_matched = (
            query_terms.intersection(target_terms)
        )

        evidence_terms_matched = (
            query_terms.intersection(relevant_evidence_terms)
        )

        # Require actual relationship, target or evidence relevance.
        if not (
            relationship_terms_matched
            or target_terms_matched
            or evidence_terms_matched
        ):
            continue

        score = (
            3 * len(relationship_terms_matched)
            + 2 * len(target_terms_matched)
            + 2 * len(evidence_terms_matched)
        )

        relationship_matches.append({
            "source_id": source,
            "target_id": target,
            "source_name": source_name,
            "target_name": target_name,
            "relationship": relationship,
            "evidence": evidence,
            "source": edge_data.get("source_file", "Unknown"),
            "page": edge_data.get("page", "Unknown"),
            "score": score
        })

        matched_entities.add(source)
        matched_entities.add(target)

    relationship_matches.sort(
        key=lambda item: (
            -item["score"],
            item["source_name"],
            item["target_name"]
        )
    )

    relationship_matches = relationship_matches[:top_k]

    entity_results = []

    for entity_id in matched_entities:

        details = get_entity(entity_id)

        if details:
            entity_results.append(details)

    return {
        "entities": entity_results,
        "relationships": relationship_matches
    }


# --------------------------------------------------
# 4. RECIPROCAL RANK FUSION
# --------------------------------------------------

def reciprocal_rank_fusion(
    vector_results,
    graph_results,
    k=60
):

    combined = []

    # Add vector evidence first.
    for rank, item in enumerate(vector_results, start=1):

        text = item.get("text", "").strip()

        combined.append({
            "source": item.get("source", "Unknown"),
            "page": item.get("page", "Unknown"),
            "text": text,
            "rrf_score": 1.0 / (k + rank),
            "retrieved_by": ["vector"]
        })

    # Deduplicate graph evidence before fusion.
    unique_graph_evidence = []
    seen_graph_evidence = set()

    for item in graph_results.get("relationships", []):

        evidence = item.get("evidence", "").strip()

        evidence_key = (
            item.get("source", "Unknown"),
            str(item.get("page", "Unknown")),
            normalize_text(evidence)
        )

        if not evidence or evidence_key in seen_graph_evidence:
            continue

        seen_graph_evidence.add(evidence_key)
        unique_graph_evidence.append(item)

    # Merge graph evidence with overlapping vector evidence.
    for rank, item in enumerate(unique_graph_evidence, start=1):

        graph_text = item.get("evidence", "").strip()

        graph_normalized = normalize_text(graph_text)

        source = item.get("source", "Unknown")
        page = item.get("page", "Unknown")

        matched_result = None

        for existing in combined:

            if (
                existing["source"] != source
                or str(existing["page"]) != str(page)
            ):
                continue

            vector_normalized = normalize_text(existing["text"])

            if (
                graph_normalized in vector_normalized
                or vector_normalized in graph_normalized
            ):
                matched_result = existing
                break

        graph_score = 1.0 / (k + rank)

        if matched_result:

            matched_result["rrf_score"] += graph_score

            if "graph" not in matched_result["retrieved_by"]:
                matched_result["retrieved_by"].append("graph")

        else:

            combined.append({
                "source": source,
                "page": page,
                "text": graph_text,
                "rrf_score": graph_score,
                "retrieved_by": ["graph"]
            })

    return sorted(
        combined,
        key=lambda item: item["rrf_score"],
        reverse=True
    )


# --------------------------------------------------
# 5. HYBRID SEARCH
# --------------------------------------------------

def hybrid_search(query, top_k=TOP_K_RESULTS, ticker=None):

    vector_results = vector_search(
        query,
        top_k=top_k,
        ticker=ticker
    )

    graph_results = graph_search(query, top_k)

    fused_results = reciprocal_rank_fusion(
        vector_results,
        graph_results
    )

    return {
        "query": query,
        "ticker": ticker,
        "vector_results": vector_results,
        "graph_results": graph_results,
        "fused_results": fused_results[:top_k]
    } 

def run_hybrid_search(query, top_k=TOP_K_RESULTS, ticker=None):

    results = hybrid_search(
        query,
        top_k=top_k,
        ticker=ticker
    )

    context = build_hybrid_context(results)

    return results, context


# --------------------------------------------------
# 6. BUILD HYBRID CONTEXT
# --------------------------------------------------

def build_hybrid_context(results):

    context_parts = []

    context_parts.append("DOCUMENT EVIDENCE:")

    for index, item in enumerate(
        results.get("vector_results", []),
        start=1
    ):

        context_parts.append(
            f"""
[Document Evidence {index}]
Source: {item['source']}
Page: {item['page']}
Content:
{item['text']}
"""
        )

    context_parts.append("\nKNOWLEDGE GRAPH EVIDENCE:")

    graph_results = results.get("graph_results", {})

    # Remove repeated evidence paragraphs from context.
    seen_evidence = set()
    unique_relationships = []

    for relationship in graph_results.get("relationships", []):

        evidence_key = (
            relationship.get("source", "Unknown"),
            str(relationship.get("page", "Unknown")),
            normalize_text(relationship.get("evidence", ""))
        )

        if evidence_key in seen_evidence:
            continue

        seen_evidence.add(evidence_key)
        unique_relationships.append(relationship)

    for index, relationship in enumerate(
        unique_relationships,
        start=1
    ):

        context_parts.append(
            f"""
[Graph Relationship {index}]
Entity 1: {relationship['source_name']}
Relationship: {relationship['relationship']}
Entity 2: {relationship['target_name']}
Evidence: {relationship['evidence']}
Source: {relationship['source']}
Page: {relationship['page']}
"""
        )

    context_parts.append("\nFUSED EVIDENCE RANKING:")

    for index, item in enumerate(
        results.get("fused_results", []),
        start=1
    ):

        context_parts.append(
            f"""
[Fused Evidence {index}]
Source: {item['source']}
Page: {item['page']}
RRF Score: {item['rrf_score']:.6f}
Retrieved By: {", ".join(item['retrieved_by'])}
Evidence:
{item['text']}
"""
        )

    context_parts.append("\nKNOWLEDGE GRAPH ENTITIES:")

    for entity in graph_results.get("entities", []):

        context_parts.append(
            f"""
Entity: {entity.get('name', 'Unknown')}
Type: {entity.get('entity_type', 'Unknown')}
Description: {entity.get('description', '')}
"""
        )

    return "\n".join(context_parts)


# --------------------------------------------------
# 7. PUBLIC FUNCTION FOR HYBRID RAG
# --------------------------------------------------

def run_hybrid_search(query, top_k=TOP_K_RESULTS, ticker=None):

    results = hybrid_search(
        query,
        top_k=top_k,
        ticker=ticker
    )

    context = build_hybrid_context(results)

    return results, context


# --------------------------------------------------
# 8. TESTING
# --------------------------------------------------

if __name__ == "__main__":

    query = "Reliance Retail strategic brand partnerships"

    print("\n" + "=" * 60)
    print("STOCKGRAPH AI - HYBRID RETRIEVAL")
    print("=" * 60)

    print(f"\nQuery: {query}")

    results, context = run_hybrid_search(query)

    print("\nVECTOR RESULTS:")
    print("Total:", len(results["vector_results"]))

    print("\nGRAPH RESULTS:")

    graph_results = results["graph_results"]

    print("Entities:", len(graph_results["entities"]))
    print("Relationships:", len(graph_results["relationships"]))

    print("\nFUSED RESULTS:")

    for item in results["fused_results"]:

        print(
            f"{item['source']} | Page {item['page']} | "
            f"Score: {item['rrf_score']:.6f} | "
            f"Methods: {', '.join(item['retrieved_by'])}"
        )

    print("\n" + "=" * 60)
    print("COMBINED RETRIEVAL CONTEXT")
    print("=" * 60)

    print(context)

    print("\n" + "=" * 60)
    print("HYBRID RETRIEVAL COMPLETED")
    print("=" * 60)
