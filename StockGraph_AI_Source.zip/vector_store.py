
import chromadb
import ollama

from config import (
    CHROMA_DIR,
    CHROMA_COLLECTION,
    OLLAMA_BASE_URL,
    EMBEDDING_MODEL,
    TOP_K_RESULTS
)


# Connect to Ollama
ollama_client = ollama.Client(
    host=OLLAMA_BASE_URL
)


# Connect to persistent ChromaDB
chroma_client = chromadb.PersistentClient(
    path=str(CHROMA_DIR)
)


# Create or load document collection
collection = chroma_client.get_or_create_collection(
    name=CHROMA_COLLECTION,
    metadata={"description": "StockGraph financial documents"}
)


def generate_embedding(text):
    """Generate an embedding using Ollama."""

    response = ollama_client.embed(
        model=EMBEDDING_MODEL,
        input=text
    )

    return response["embeddings"][0]


def store_chunks(chunks):
    """Generate embeddings and store PDF chunks in ChromaDB."""

    if not chunks:
        raise ValueError("No chunks provided.")

    ids = []
    documents = []
    metadatas = []
    embeddings = []

    for chunk in chunks:
        ids.append(chunk["id"])
        documents.append(chunk["text"])
        metadatas.append(chunk["metadata"])
        embeddings.append(generate_embedding(chunk["text"]))

    collection.upsert(
        ids=ids,
        documents=documents,
        metadatas=metadatas,
        embeddings=embeddings
    )

    return len(ids)


def search_documents(query, top_k=TOP_K_RESULTS, where=None):
    """Find relevant document chunks using semantic search."""

    if not query.strip():
        raise ValueError("Search query cannot be empty.")

    total_documents = collection.count()

    if total_documents == 0:
        return []

    query_embedding = generate_embedding(query)

    query_args = {
        "query_embeddings": [query_embedding],
        "n_results": min(top_k, total_documents)
    }

    # Apply optional metadata filtering.
    if where:
        query_args["where"] = where

    results = collection.query(**query_args)

    matches = []

    if results["documents"]:
        for i, document in enumerate(results["documents"][0]):
            matches.append({
                "text": document,
                "metadata": results["metadatas"][0][i],
                "distance": results["distances"][0][i]
            })

    return matches

    matches = []

    if results["documents"]:
        for i, document in enumerate(results["documents"][0]):
            matches.append({
                "text": document,
                "metadata": results["metadatas"][0][i],
                "distance": results["distances"][0][i]
            })

    return matches



def store_chunks(chunks, batch_size=32):
    """Generate embeddings in batches and store them in ChromaDB."""

    if not chunks:
        raise ValueError("No chunks provided.")

    total_stored = 0

    for start in range(0, len(chunks), batch_size):
        batch = chunks[start:start + batch_size]

        ids = [chunk["id"] for chunk in batch]
        documents = [chunk["text"] for chunk in batch]
        metadatas = [chunk["metadata"] for chunk in batch]

        response = ollama_client.embed(
            model=EMBEDDING_MODEL,
            input=documents
        )

        embeddings = response["embeddings"]

        collection.upsert(
            ids=ids,
            documents=documents,
            metadatas=metadatas,
            embeddings=embeddings
        )

        total_stored += len(batch)

        print(
            f"Embedded and stored: "
            f"{total_stored}/{len(chunks)}"
        )

    return total_stored
def get_document_count():
    """Return the total number of stored chunks."""
    return collection.count()