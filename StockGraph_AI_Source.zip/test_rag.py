
from rag_evaluation import validate_citations


def test_valid_citation():
    answer = (
        "Reliance Retail partnered with Stella McCartney. "
        "(Source: r2.pdf, Page: 41)"
    )

    sources = [
        ("r2.pdf", "41"),
        ("r2.pdf", "7")
    ]

    result = validate_citations(answer, sources)

    assert result["total_citations"] == 1
    assert len(result["valid_citations"]) == 1
    assert len(result["invalid_citations"]) == 0
    assert result["all_citations_valid"] is True


def test_invalid_citation():
    answer = (
        "Reliance Retail partnered with Stella McCartney. "
        "(Source: r2.pdf, Page: 99)"
    )

    sources = [
        ("r2.pdf", "41"),
        ("r2.pdf", "7")
    ]

    result = validate_citations(answer, sources)

    assert result["total_citations"] == 1
    assert len(result["valid_citations"]) == 0
    assert len(result["invalid_citations"]) == 1
    assert result["all_citations_valid"] is False


def test_missing_citation():
    answer = (
        "Reliance Retail partnered with Stella McCartney."
    )

    sources = [
        ("r2.pdf", "41")
    ]

    result = validate_citations(answer, sources)

    assert result["total_citations"] == 0
    assert result["has_citations"] is False
    assert result["all_citations_valid"] is False


def test_multiple_citations():
    answer = (
        "Reliance Retail entered partnerships with several brands. "
        "(Source: r2.pdf, Page: 41) "
        "(Source: r2.pdf, Page: 7)"
    )

    sources = [
        ("r2.pdf", "41"),
        ("r2.pdf", "7")
    ]

    result = validate_citations(answer, sources)

    assert result["total_citations"] == 2
    assert len(result["valid_citations"]) == 2
    assert len(result["invalid_citations"]) == 0
    assert result["all_citations_valid"] is True
