
import ollama

from config import LLM_MODEL, OLLAMA_BASE_URL
from hybrid_retrieval import run_hybrid_search
from rag_evaluation import validate_citations
from financial_attribution import (
    classify_evidence,
    classify_financial_content
)


# Initialize Ollama client
client = ollama.Client(host=OLLAMA_BASE_URL)


SYSTEM_PROMPT = """
You are StockGraph AI, a financial research assistant.

CORE RULES:
1. Never invent financial figures, facts, relationships, or events.
2. Use only the retrieved document and Knowledge Graph evidence.
3. Identify the exact company or subsidiary mentioned in the evidence.
4. Never confuse Reliance Retail Ventures Limited with Reliance Industries Limited.
5. Answer directly whenever relevant evidence is available.
6. Distinguish Revenue, Profit Before Tax (PBT), and Profit After Tax (PAT).
7. Preserve financial years, dates, currencies, and units exactly.
8. Never infer missing financial figures.
9. If evidence is insufficient, clearly identify what is missing.

ANALYSIS RULES:
10. Identify financial risks such as:
    - Market risk
    - Foreign currency risk
    - Interest rate risk
    - Commodity price risk
    - Credit risk
    - Liquidity risk

11. Identify growth opportunities only when supported by evidence.
12. Clearly distinguish documented facts from analytical interpretation.
13. Do not present a potential opportunity as a confirmed future event.
14. Do not confuse risk mitigation measures with elimination of risk.

CITATION RULES:
15. Cite every factual claim using:
    (Source: filename.pdf, Page: 10)
16. Place citations immediately after relevant claims.
17. Never fabricate filenames or page numbers.
18. A valid citation does not automatically make a claim correct.

RESPONSE RULES:
19. Organize answers using headings and bullet points when useful.
20. Answer all supported parts of the question.
21. Explicitly mention unsupported parts.
22. Never use outside knowledge.
23. Never refuse when retrieved evidence directly contains the answer.

Provide concise, evidence-grounded financial analysis.
"""


def build_prompt(question, context, attribution_context):

    question_lower = question.lower()

    entity_instruction = ""

    if (
        "reliance retail ventures limited" in question_lower
        or "rrvl" in question_lower
    ):
        entity_instruction = """
CRITICAL REPORTING ENTITY RESTRICTION:

The requested reporting entity is Reliance Retail Ventures Limited (RRVL).

1. Use ONLY evidence explicitly attributed to Reliance Retail Ventures Limited.
2. Do not use Reliance Industries Limited (RIL) consolidated figures.
3. Do not use Reliance Retail business-performance disclosures.
4. Do not use RIL segment information as a substitute for RRVL financial statements.
5. Use the reporting period explicitly requested by the user.
6. If a requested metric is absent from RRVL evidence, say it is unavailable.
7. Never substitute figures from another company, even if the metric has
   the same name.
"""

    return f"""
{SYSTEM_PROMPT}

{entity_instruction}

USER QUESTION:
{question}

FINANCIAL ATTRIBUTION METADATA:
{attribution_context}

RETRIEVED EVIDENCE:
{context}

ANSWERING INSTRUCTIONS:

1. Identify every metric or fact requested.
2. Answer every requested part separately.
3. Use only figures explicitly present in retrieved evidence.
4. Match each figure to its exact reporting entity, reporting scope,
   business segment and financial year.
5. Never mix Reliance Retail, Reliance Retail Ventures Limited (RRVL),
   and Reliance Industries Limited (RIL) figures.
6. Distinguish Gross Revenue, Value of Sales and Services,
   and Revenue from Operations.
7. If evidence provides the requested figure, do not say it is unavailable.
8. If evidence is insufficient for a requested metric, state that clearly.
9. Do not copy unrelated financial figures into the answer.

CITATION FORMAT:

Every factual claim must include a citation in this format:

(Source: r2.pdf, Page: 145)

Use only the actual filename and page number from retrieved evidence.
Do not invent citations.
Place citations immediately after relevant claims.

RESPONSE FORMAT:

## Answer

- **Metric 1:** Exact value and unit.
- **Metric 2:** Exact value and unit.

## Reporting Attribution

State the reporting entity and whether the figures represent
business-performance disclosures, standalone statements or
consolidated statements.

## Sources

List the source filename and page number.

ANSWER:
"""


def build_attribution_context(vector_results):
    """Create reporting attribution and financial content metadata."""

    sections = []

    for index, item in enumerate(vector_results, start=1):

        text = item.get("text", "")

        attribution = classify_evidence(
            item.get("source", "Unknown"),
            item.get("page", 0),
            text
        )

        classification = classify_financial_content(text)

        sections.append(
            f"""
Evidence Reference: {item.get('source')} | Page {item.get('page')}
Reporting Entity: {attribution['reporting_entity']}
Reporting Scope: {attribution['reporting_scope']}
Business Segment: {attribution['business_segment']}
Reporting Period: {attribution['reporting_period']}
Evidence Type: {attribution['evidence_type']}
Attribution Confidence: {attribution['attribution_confidence']}
Evidence Categories: {", ".join(classification['evidence_categories'])}
Detected Metrics: {", ".join(classification['detected_metrics']) or "None"}
"""
        )

    return "\n".join(sections)


def is_rrvl_question(question):
    """Identify explicit requests for RRVL reporting information."""

    import re

    normalized = str(question).lower()

    return (
        "reliance retail ventures limited" in normalized
        or bool(re.search(r"\\brrvl\\b", normalized))
    )


def is_reliance_retail_business_question(question):
    """Identify Reliance Retail business-performance questions."""

    normalized = str(question).lower()

    return (
        "reliance retail" in normalized
        and not is_rrvl_question(normalized)
    )


def filter_rrvl_evidence(vector_results):
    """Keep explicitly attributed RRVL consolidated evidence."""

    filtered = []

    for item in vector_results:
        attribution = classify_evidence(
            item.get("source", "Unknown"),
            item.get("page", 0),
            item.get("text", "")
        )

        if (
            attribution["reporting_entity"]
            == "Reliance Retail Ventures Limited"
            and attribution["reporting_scope"] == "Consolidated"
        ):
            filtered.append(item)

    return filtered


def filter_reliance_retail_business_evidence(vector_results):
    """Keep Reliance Retail business-performance evidence only."""

    filtered = []

    for item in vector_results:
        attribution = classify_evidence(
            item.get("source", "Unknown"),
            item.get("page", 0),
            item.get("text", "")
        )

        if (
            attribution["reporting_entity"]
            == "Reliance Retail business"
            and attribution["reporting_scope"]
            == "Business performance disclosure"
        ):
            filtered.append(item)

    return filtered


def format_vector_context(vector_results):
    """Build a clean context using only the supplied vector evidence."""

    sections = []

    for index, item in enumerate(vector_results, start=1):

        sections.append(
            f"""
DOCUMENT EVIDENCE {index}

Source: {item.get('source')}
Page: {item.get('page')}

Content:
{item.get('text', '')}
"""
        )

    return "\n".join(sections)


def answer_question(question, top_k=5, ticker=None):

    # Validate question
    if not question or not question.strip():

        return {
            "answer": "Please enter a valid question.",
            "sources": [],
            "retrieval": None,
            "citation_report": None
        }

    print("\nSearching documents and Knowledge Graph...")

    # Retrieve documents and graph evidence

    results, context = run_hybrid_search(
        question,
        top_k=top_k,
        ticker=ticker
    )

    vector_results = results["vector_results"]
    graph_results = results["graph_results"]

    # Stop if no evidence was retrieved
    if not vector_results and not graph_results["relationships"]:

        return {
            "answer": (
                "I could not find relevant evidence in the "
                "available documents or Knowledge Graph."
            ),
            "sources": [],
            "retrieval": results,
            "citation_report": None
        }

    # Display original retrieval results
    print("\n========== DEBUG: RETRIEVED CONTEXT ==========")
    print(context)
    print("\n========== END OF CONTEXT ==========")

       # Identify the requested reporting entity.
    rrvl_only = is_rrvl_question(question)
    retail_business_only = is_reliance_retail_business_question(question)

    # Path 1: RRVL consolidated financial statements.
    if rrvl_only:

        print("\nApplying RRVL consolidated evidence filter...")

        vector_results = filter_rrvl_evidence(vector_results)

        if not vector_results:
            return {
                "answer": (
                    "No explicitly attributed RRVL consolidated "
                    "financial evidence was retrieved."
                ),
                "sources": [],
                "retrieval": results,
                "citation_report": None
            }

        context = format_vector_context(vector_results)
        relevant_graph_relationships = []

    # Path 2: Reliance Retail business performance.
    elif retail_business_only:

        print("\nApplying Reliance Retail business evidence filter...")

        vector_results = filter_reliance_retail_business_evidence(
            vector_results
        )

        if not vector_results:
            return {
                "answer": (
                    "No explicitly attributed Reliance Retail "
                    "business-performance evidence was retrieved."
                ),
                "sources": [],
                "retrieval": results,
                "citation_report": None
            }

        context = format_vector_context(vector_results)
        relevant_graph_relationships = []

    # Path 3: General ticker-specific research.
    elif ticker:

        print(f"\nApplying ticker evidence filter: {ticker}")

        if not vector_results:
            return {
                "answer": (
                    f"No document evidence was found for {ticker}. "
                    "Upload and tag documents for this ticker first."
                ),
                "sources": [],
                "retrieval": results,
                "citation_report": None
            }

        context = format_vector_context(vector_results)
        relevant_graph_relationships = []
    # Path 4: Unfiltered hybrid research.
    else:

        relevant_graph_relationships = graph_results["relationships"]

    # Build attribution metadata after evidence filtering.
    attribution_context = build_attribution_context(
        vector_results
    )

    # Build final prompt
    prompt = build_prompt(
        question,
        context,
        attribution_context
    )

    print("\nGenerating answer with Ollama...")

    # Generate answer
    response = client.generate(
        model=LLM_MODEL,
        prompt=prompt,
        options={
            "temperature": 0
        }
    )

    answer = response["response"].strip()

    # Collect only sources supplied to the model
    sources = set()

    for item in vector_results:

        sources.add((
            str(item["source"]),
            str(item["page"])
        ))

    # Add Knowledge Graph sources only when not using RRVL-only evidence
    for item in relevant_graph_relationships:

        sources.add((
            str(item["source"]),
            str(item["page"])
        ))

    # Validate citations
    citation_report = validate_citations(
        answer,
        sources
    )

    print("\n========== CITATION VALIDATION ==========")

    print(
        "Total citations:",
        citation_report["total_citations"]
    )

    print(
        "Valid citations:",
        len(citation_report["valid_citations"])
    )

    print(
        "Invalid citations:",
        len(citation_report["invalid_citations"])
    )

    if citation_report["all_citations_valid"]:

        print("Citation status: PASSED")

    else:

        print("Citation status: FAILED")

    if citation_report["invalid_citations"]:

        print("Invalid citation details:")
        print(citation_report["invalid_citations"])

    print("=========================================")

    # Return complete result
    return {
        "answer": answer,
        "sources": sorted(sources),
        "retrieval": results,
        "citation_report": citation_report
    }


# Main program
if __name__ == "__main__":

    print("=" * 60)
    print("STOCKGRAPH AI - HYBRID RAG ASSISTANT")
    print("=" * 60)

    question = input("\nAsk a question: ").strip()

    result = answer_question(question)

    print("\n" + "=" * 60)
    print("AI ANSWER")
    print("=" * 60)

    print(result["answer"])

    print("\n" + "=" * 60)
    print("RETRIEVED SOURCES")
    print("=" * 60)

    for source, page in result["sources"]:

        print(f"{source} | Page {page}")


    print("\n" + "=" * 60)
    print("COMPLETED")
    print("=" * 60)
