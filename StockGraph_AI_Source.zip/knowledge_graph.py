
import json
from pathlib import Path

import networkx as nx

from config import DATA_DIR


# --------------------------------------------------
# KNOWLEDGE GRAPH INITIALIZATION
# --------------------------------------------------

GRAPH_FILE = DATA_DIR / "stockgraph_knowledge_graph.graphml"

graph = nx.MultiDiGraph()


# --------------------------------------------------
# ADD ENTITY
# --------------------------------------------------

def add_entity(entity_id, name, entity_type, description=""):
    """
    Add a company, business segment, metric,
    subsidiary or other entity to the graph.
    """

    if not entity_id or not name or not entity_type:
        raise ValueError(
            "Entity ID, name and type are required."
        )

    graph.add_node(
        str(entity_id),
        name=str(name),
        entity_type=str(entity_type),
        description=str(description)
    )

    return str(entity_id)


# --------------------------------------------------
# ADD RELATIONSHIP
# --------------------------------------------------


def add_relationship(source_id, target_id, relationship, source_file, page, evidence):
    source_id = str(source_id)
    target_id = str(target_id)

    if source_id not in graph:
        raise ValueError(f"Source entity not found: {source_id}")

    if target_id not in graph:
        raise ValueError(f"Target entity not found: {target_id}")

    if not relationship or not source_file or not evidence:
        raise ValueError("Relationship, source file and evidence are required.")

    if page is None or str(page).strip() == "":
        raise ValueError("Page number is required.")

    # Prevent duplicate relationships
    for _, _, existing in graph.edges(source_id, data=True):
        if (
            existing.get("relationship") == str(relationship)
            and existing.get("source_file") == str(source_file)
            and existing.get("page") == str(page)
            and existing.get("evidence") == str(evidence)
        ):
            # This exact source-target relationship already exists
            for target, data in graph[source_id].items():
                if target == target_id:
                    for edge_data in data.values():
                        if (
                            edge_data.get("relationship") == str(relationship)
                            and edge_data.get("source_file") == str(source_file)
                            and edge_data.get("page") == str(page)
                            and edge_data.get("evidence") == str(evidence)
                        ):
                            return False

    graph.add_edge(
        source_id,
        target_id,
        relationship=str(relationship),
        source_file=str(source_file),
        page=str(page),
        evidence=str(evidence)
    )

    return True


# --------------------------------------------------
# GET ENTITY DETAILS
# --------------------------------------------------


def get_entity(entity_id):
    entity_id = str(entity_id)

    if entity_id not in graph:
        return None

    node_data = graph.nodes[entity_id]

    entity = {
        "id": entity_id,
        "name": node_data.get("name", "Unknown"),
        "entity_type": node_data.get("entity_type", "Unknown"),
        "description": node_data.get("description", "")
    }

    relationships = []

    for source, target, data in graph.in_edges(
        entity_id, data=True
    ):
        relationships.append({
            "direction": "incoming",
            "entity": graph.nodes[source].get("name", "Unknown"),
            "relationship": data.get("relationship", ""),
            "source_file": data.get("source_file", ""),
            "page": data.get("page", ""),
            "evidence": data.get("evidence", "")
        })

    for source, target, data in graph.out_edges(
        entity_id, data=True
    ):
        relationships.append({
            "direction": "outgoing",
            "entity": graph.nodes[target].get("name", "Unknown"),
            "relationship": data.get("relationship", ""),
            "source_file": data.get("source_file", ""),
            "page": data.get("page", ""),
            "evidence": data.get("evidence", "")
        })

    entity["relationships"] = relationships

    return entity


# --------------------------------------------------
# SEARCH ENTITIES
# --------------------------------------------------

def search_entities(keyword):
    """Search entity names and descriptions."""

    keyword = keyword.lower().strip()

    if not keyword:
        return []

    results = []

    for entity_id, data in graph.nodes(data=True):

        name = data.get("name", "")
        description = data.get("description", "")

        if (
            keyword in name.lower()
            or keyword in description.lower()
        ):
            results.append({
                "id": entity_id,
                **data
            })

    return results


# --------------------------------------------------
# GET GRAPH STATISTICS
# --------------------------------------------------

def get_graph_statistics():
    """Return basic graph statistics."""

    entity_types = {}

    for _, data in graph.nodes(data=True):

        entity_type = data.get(
            "entity_type",
            "unknown"
        )

        entity_types[entity_type] = (
            entity_types.get(entity_type, 0) + 1
        )

    return {
        "total_entities": graph.number_of_nodes(),
        "total_relationships": graph.number_of_edges(),
        "entity_types": entity_types
    }


# --------------------------------------------------
# SAVE KNOWLEDGE GRAPH
# --------------------------------------------------

def save_graph(file_path=GRAPH_FILE):
    """Save graph as a GraphML file."""

    file_path = Path(file_path)
    file_path.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    nx.write_graphml(graph, file_path)

    return str(file_path)


# --------------------------------------------------
# LOAD KNOWLEDGE GRAPH
# --------------------------------------------------



def load_graph(file_path=GRAPH_FILE):
    if not Path(file_path).exists():
        print("Knowledge Graph file not found.")
        return False

    loaded_graph = nx.read_graphml(file_path, node_type=str)

    # Update the existing graph object instead of replacing it.
    graph.clear()

    graph.add_nodes_from(loaded_graph.nodes(data=True))

    if loaded_graph.is_multigraph():
        graph.add_edges_from(
            (source, target, key, data)
            for source, target, key, data
            in loaded_graph.edges(keys=True, data=True)
        )
    else:
        graph.add_edges_from(
            (source, target, data)
            for source, target, data
            in loaded_graph.edges(data=True)
        )

    print(
        f"Knowledge Graph loaded: "
        f"{graph.number_of_nodes()} entities, "
        f"{graph.number_of_edges()} relationships"
    )

    return True


# --------------------------------------------------
# EXPORT GRAPH DATA AS JSON
# --------------------------------------------------

def export_graph_json():
    """Export graph entities and relationships as JSON."""

    nodes = []

    for entity_id, data in graph.nodes(data=True):

        nodes.append({
            "id": entity_id,
            **data
        })

    relationships = []

    for source, target, data in graph.edges(data=True):

        relationships.append({
            "source": source,
            "target": target,
            **data
        })

    return json.dumps(
        {
            "entities": nodes,
            "relationships": relationships
        },
        indent=4,
        ensure_ascii=False
    )


# --------------------------------------------------
# MODULE TEST
# --------------------------------------------------

if __name__ == "__main__":

    print("=" * 50)
    print("STOCKGRAPH AI - KNOWLEDGE GRAPH")
    print("=" * 50)

    print("NetworkX version:", nx.__version__)

    print(
        "Knowledge Graph initialized successfully."
    )

    print(
        "Graph storage:",
        GRAPH_FILE
    )

    print(
        "Current statistics:",
        get_graph_statistics()
    )
