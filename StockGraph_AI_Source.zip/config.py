import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

DATA_DIR = BASE_DIR / "data"
CHROMA_DIR = BASE_DIR / "chroma_db"
GRAPH_DIR = BASE_DIR / "graphs"
KNOWLEDGE_BASE_DIR = BASE_DIR / "knowledge_base"
REPORTS_DIR = BASE_DIR / "reports"

# Create required directories
for directory in [
    DATA_DIR,
    CHROMA_DIR,
    GRAPH_DIR,
    KNOWLEDGE_BASE_DIR,
    REPORTS_DIR
]:
    directory.mkdir(parents=True, exist_ok=True)

# Ollama configuration
OLLAMA_BASE_URL = os.getenv(
    "OLLAMA_BASE_URL",
    "http://localhost:11434"
)

LLM_MODEL = os.getenv("LLM_MODEL", "qwen2.5:3b")

EMBEDDING_MODEL = os.getenv(
    "EMBEDDING_MODEL",
    "nomic-embed-text"
)

# RAG configuration
CHROMA_COLLECTION = "stockgraph_documents"

CHUNK_SIZE = 1000
CHUNK_OVERLAP = 200
TOP_K_RESULTS = 5

print("StockGraph AI configuration loaded successfully.")