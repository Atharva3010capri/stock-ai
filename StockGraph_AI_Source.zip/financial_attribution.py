
"""
Financial evidence attribution for StockGraph AI.
Uses explicit document headings and evidence text.
Does not modify ChromaDB or embeddings.
"""


def classify_evidence(source, page, text):
    source = str(source)
    page = int(page)
    text = str(text)
    normalized = " ".join(text.lower().split())

    result = {
        "source": source,
        "page": page,
        "reporting_entity": "Unverified",
        "reporting_scope": "Unverified",
        "business_segment": None,
        "reporting_period": None,
        "evidence_type": "General document evidence",
        "attribution_confidence": "Low"
    }

    if source.lower() != "r2.pdf":
        return result

    # Specific subsidiary attribution must come before RIL attribution.
    if (
        "reliance retail ventures limited" in normalized
        and "consolidated financial statements" in normalized
    ):
        result.update({
            "reporting_entity": "Reliance Retail Ventures Limited",
            "reporting_scope": "Consolidated",
            "reporting_period": "FY 2025-26 and FY 2024-25",
            "evidence_type": "Subsidiary consolidated financial statement",
            "attribution_confidence": "High"
        })
        return result

    # RIL consolidated segment information.
    if (
        page == 130
        and "reliance industries limited" in normalized
        and "consolidated financial statements" in normalized
        and "segment revenue" in normalized
    ):
        result.update({
            "reporting_entity": "Reliance Industries Limited",
            "reporting_scope": "Consolidated",
            "business_segment": "Retail and other reported segments",
            "reporting_period": "FY 2024-25",
            "evidence_type": "Consolidated segment information",
            "attribution_confidence": "High"
        })
        return result

    # Retail business performance disclosures.
    retail_section = (
        "reliance retail recorded gross revenue" in normalized
        or "financial performance and review retail" in normalized
        or (
            "reliance retail" in normalized
            and "ebitda margin" in normalized
            and "revenue from operations" in normalized
        )
    )

    if page in (6, 7) and retail_section:
        result.update({
            "reporting_entity": "Reliance Retail business",
            "reporting_scope": "Business performance disclosure",
            "business_segment": "Retail",
            "reporting_period": "FY 2025-26",
            "evidence_type": "Retail business performance",
            "attribution_confidence": "Medium"
        })
        return result

    # RIL consolidated financial statements.
    if (
        "reliance industries limited" in normalized
        and "consolidated financial statements" in normalized
    ):
        result.update({
            "reporting_entity": "Reliance Industries Limited",
            "reporting_scope": "Consolidated",
            "reporting_period": "FY 2025-26",
            "evidence_type": "Consolidated financial statement",
            "attribution_confidence": "High"
        })
        return result

    # RIL standalone financial statements.
    if (
        "reliance industries limited" in normalized
        and "standalone financial statements" in normalized
    ):
        result.update({
            "reporting_entity": "Reliance Industries Limited",
            "reporting_scope": "Standalone",
            "reporting_period": "FY 2025-26",
            "evidence_type": "Standalone financial statement",
            "attribution_confidence": "High"
        })
        return result

    return result

def classify_financial_content(text):
    """
    Classify the subject matter of retrieved financial evidence.
    Supports multiple categories per document chunk.
    """

    import re

    normalized = " ".join(str(text).lower().split())

    categories = []
    detected_metrics = []

    patterns = {
        "Financial Performance": [
            r"\brevenue\b",
            r"\bebitda\b",
            r"\bprofit before tax\b",
            r"\bprofit after tax\b",
            r"\bpat\b",
            r"\bpbt\b",
            r"\bmargin\b",
            r"\bearnings\b",
            r"\bturnover\b"
        ],
        "Balance Sheet": [
            r"\btotal assets\b",
            r"\btotal liabilities\b",
            r"\bborrowings\b",
            r"\bshareholders'? equity\b",
            r"\bnet worth\b",
            r"\bcurrent assets\b"
        ],
        "Cash Flow": [
            r"\bcash flow\b",
            r"\boperating activities\b",
            r"\binvesting activities\b",
            r"\bfinancing activities\b"
        ],
        "Segment Performance": [
            r"\bbusiness segment\b",
            r"\bsegment revenue\b",
            r"\bsegment results\b",
            r"\breliance retail\b",
            r"\bconsumer electronics\b"
        ],
        "Risk Disclosure": [
            r"\bcredit risk\b",
            r"\bliquidity risk\b",
            r"\bmarket risk\b",
            r"\bforeign currency risk\b",
            r"\binterest rate risk\b",
            r"\bcommodity price risk\b"
        ],
        "Strategy & Growth": [
            r"\bstrategic partnership\b",
            r"\bexpansion\b",
            r"\binvestment\b",
            r"\bnew market\b",
            r"\bgrowth strategy\b"
        ],
        "Operational Performance": [
            r"\bnumber of stores\b",
            r"\bregistered customer\b",
            r"\btransactions\b",
            r"\bretail area\b",
            r"\bproduction capacity\b"
        ]
    }

    for category, expressions in patterns.items():
        if any(re.search(pattern, normalized) for pattern in expressions):
            categories.append(category)

    metric_patterns = {
        "Revenue": r"\brevenue\b",
        "EBITDA": r"\bebitda\b",
        "EBITDA Margin": r"\bebitda margin\b",
        "Profit Before Tax": r"\bprofit before tax\b|\bpbt\b",
        "Profit After Tax": r"\bprofit after tax\b|\bpat\b",
        "Cash Flow": r"\bcash flow\b",
        "Total Assets": r"\btotal assets\b",
        "Borrowings": r"\bborrowings\b"
    }

    for metric, pattern in metric_patterns.items():
        if re.search(pattern, normalized):
            detected_metrics.append(metric)

    if not categories:
        categories.append("General")

    return {
        "evidence_categories": categories,
        "detected_metrics": detected_metrics
    }


def format_attributed_evidence(vector_results):
    """Format retrieved chunks with their attribution labels."""

    sections = []

    for index, item in enumerate(vector_results, start=1):
        source = item.get("source", "Unknown")
        page = item.get("page", 0)
        text = item.get("text", "")

        attribution = classify_evidence(source, page, text)

        sections.append(f"""
EVIDENCE {index}
Source: {source}
Page: {page}

REPORTING ATTRIBUTION:
Reporting Entity: {attribution['reporting_entity']}
Reporting Scope: {attribution['reporting_scope']}
Business Segment: {attribution['business_segment']}
Reporting Period: {attribution['reporting_period']}
Evidence Type: {attribution['evidence_type']}
Attribution Confidence: {attribution['attribution_confidence']}

DOCUMENT CONTENT:
{text}
""")

    return "\n".join(sections)
