
import re

from config import TOP_K_RESULTS
from vector_store import search_documents
from knowledge_graph import (
    graph,
    load_graph,
    search_entities,
    get_entity,
)


# Load the saved Knowledge Graph
load_graph()


def extract_query_terms(query):
    """
    Clean query and remove common stop words.
    """

    stop_words = {
        "the", "and", "for", "with", "from",
        "what", "which", "when", "where", "who",
        "how", "why", "are", "is", "was", "were",
        "does", "do", "did", "can", "could",
        "would", "should", "about", "company",
        "companies", "their", "this", "that",
        "these", "those", "into", "its"
    }

    words = re.findall(r"[a-zA-Z0-9]+", query.lower())

    return {
        word for word in words
        if len(word) > 2 and word not in stop_words
    }


def vector_search(query, top_k=TOP_K_RESULTS):
    """
    Retrieve relevant document chunks from ChromaDB.
    """

    documents = search_documents(query, top_k=top_k)

    results = []

    for document in documents:
        metadata = document.get("metadata", {})

        results.append({
            "text": document.get("text", ""),
            "source": metadata.get("source", "Unknown"),
            "page": metadata.get("page", "Unknown"),
            "distance": document.get("distance"),
            "type": "vector"
        })

    return results


def graph_search(query, top_k=TOP_K_RESULTS):
    """
    Search Knowledge Graph entities and relationships.
    Uses cleaned keywords and ranks matching evidence.
    """

    query_terms = extract_query_terms(query)

    if not query_terms:
        return {
            "entities": [],
            "relationships": []
        }

    matched_entities = set()

    # 1. Match entity names and descriptions
    for entity in search_entities(query):
        matched_entities.add(entity["id"])

    # 2. Match relationship evidence and metadata
    relationship_matches = []

    for source, target, edge_data in graph.edges(data=True):

        source_name = graph.nodes[source].get("name", "")
        target_name = graph.nodes[target].get("name", "")

        searchable_text = " ".join([
            source_name,
            target_name,
            edge_data.get("relationship", ""),
            edge_data.get("evidence", ""),
            edge_data.get("source_file", "")
        ]).lower()

        searchable_words = set(
            re.findall(r"[a-zA-Z0-9]+", searchable_text)
        )

        matched_terms = query_terms.intersection(searchable_words)

        if matched_terms:
            relationship_matches.append({
                "source_id": source,
                "target_id": target,
                "source_name": source_name,
                "target_name": target_name,
                "relationship": edge_data.get("relationship", ""),
                "evidence": edge_data.get("evidence", ""),
                "source": edge_data.get("source_file", "Unknown"),
                "page": edge_data.get("page", "Unknown"),
                "score": len(matched_terms)
            })

            matched_entities.add(source)
            matched_entities.add(target)

    # 3. Rank relationship matches
    relationship_matches.sort(
        key=lambda item: item["score"],
        reverse=True
    )

    relationship_matches = relationship_matches[:top_k]

    # 4. Retrieve matched entity details
    entity_results = []

    for entity_id in matched_entities:
        details = get_entity(entity_id)

        if details:
            entity_results.append(details)

    return {
        "entities": entity_results,
        "relationships": relationship_matches
    }


def hybrid_search(query, top_k=TOP_K_RESULTS):
    """
    Combine vector retrieval and Knowledge Graph retrieval.
    """

    vector_results = vector_search(query, top_k)

    graph_results = graph_search(query, top_k)

    return {
        "query": query,
        "vector_results": vector_results,
        "graph_results": graph_results
    }


def build_hybrid_context(results):
    """
    Convert vector and graph results into context for an LLM.
    Every evidence item retains its source and page.
    """

    context_parts = []

    # Vector database evidence
    context_parts.append("DOCUMENT EVIDENCE:")

    for index, item in enumerate(
        results.get("vector_results", []), start=1
    ):
        context_parts.append(
            f"""
[Document Evidence {index}]
Source: {item['source']}
Page: {item['page']}
Content:
{item['text']}
"""
        )

    # Knowledge Graph evidence
    context_parts.append("\nKNOWLEDGE GRAPH EVIDENCE:")

    graph_results = results.get("graph_results", {})

    for index, relationship in enumerate(
        graph_results.get("relationships", []), start=1
    ):
        context_parts.append(
            f"""
[Graph Relationship {index}]
Entity 1: {relationship['source_name']}
Relationship: {relationship['relationship']}
Entity 2: {relationship['target_name']}
Evidence: {relationship['evidence']}
Source: {relationship['source']}
Page: {relationship['page']}
"""
        )

    # Entity information
    context_parts.append("\nKNOWLEDGE GRAPH ENTITIES:")

    for entity in graph_results.get("entities", []):
        context_parts.append(
            f"""
Entity: {entity.get('name', 'Unknown')}
Type: {entity.get('entity_type', 'Unknown')}
Description: {entity.get('description', '')}
"""
        )

    return "\n".join(context_parts)


def run_hybrid_search(query, top_k=TOP_K_RESULTS):
    """
    Run the complete hybrid retrieval pipeline.
    """

    results = hybrid_search(query, top_k)

    context = build_hybrid_context(results)

    return results, context


if __name__ == "__main__":

    query = "Reliance Retail strategic brand partnerships"

    print("\n" + "=" * 60)
    print("STOCKGRAPH AI - HYBRID RETRIEVAL")
    print("=" * 60)

    print(f"\nQuery: {query}")

    results, context = run_hybrid_search(query)

    print("\nVECTOR RESULTS:")
    print("Total:", len(results["vector_results"]))

    print("\nGRAPH RESULTS:")

    graph_results = results["graph_results"]

    print("Entities:", len(graph_results["entities"]))
    print("Relationships:", len(graph_results["relationships"]))

    print("\n" + "=" * 60)
    print("COMBINED RETRIEVAL CONTEXT")
    print("=" * 60)

    print(context)

    print("\n" + "=" * 60)
    print("HYBRID RETRIEVAL COMPLETED")
    print("=" * 60)
