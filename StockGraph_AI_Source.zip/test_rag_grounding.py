
from rag_evaluation import check_claim_support


EVIDENCE = """
During the year, the business entered into strategic brand
partnerships with Stella McCartney, Kurt Geiger, Max & Co.
and Fabletics, reinforcing Reliance Retail's position as
the partner of choice for international brands entering India.
"""


def test_supported_claims():

    claims = [
        "Stella McCartney",
        "Kurt Geiger",
        "Max & Co.",
        "Fabletics"
    ]

    result = check_claim_support(claims, EVIDENCE)

    assert result["total_claims"] == 4
    assert len(result["supported_claims"]) == 4
    assert len(result["unsupported_claims"]) == 0
    assert result["all_claims_supported"] is True


def test_unsupported_claim():

    claims = [
        "Stella McCartney",
        "Nike"
    ]

    result = check_claim_support(claims, EVIDENCE)

    assert len(result["supported_claims"]) == 1
    assert len(result["unsupported_claims"]) == 1
    assert "Nike" in result["unsupported_claims"]
    assert result["all_claims_supported"] is False


def test_empty_claims():

    result = check_claim_support([], EVIDENCE)

    assert result["total_claims"] == 0
    assert result["all_claims_supported"] is False


def test_empty_evidence():

    claims = ["Stella McCartney"]

    result = check_claim_support(claims, "")

    assert len(result["unsupported_claims"]) == 1
    assert result["all_claims_supported"] is False
