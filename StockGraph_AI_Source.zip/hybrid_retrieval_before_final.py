
import re

from config import TOP_K_RESULTS
from vector_store import search_documents
from knowledge_graph import graph, load_graph, get_entity

load_graph()


# --------------------------------------------------
# 1. QUERY PROCESSING
# --------------------------------------------------

STOP_WORDS = {
    "the", "and", "for", "with", "from", "what",
    "which", "when", "where", "who", "how", "why",
    "are", "is", "was", "were", "does", "do", "did",
    "can", "could", "would", "should", "about",
    "their", "this", "that", "these", "those",
    "into", "its", "during", "between", "have",
    "has", "had", "company", "companies"
}


def extract_query_terms(query):

    words = re.findall(r"[a-zA-Z0-9]+", query.lower())

    return {
        word for word in words
        if len(word) > 2 and word not in STOP_WORDS
    }


# --------------------------------------------------
# 2. VECTOR SEARCH
# --------------------------------------------------

def vector_search(query, top_k=TOP_K_RESULTS):

    documents = search_documents(query, top_k=top_k)

    results = []

    for document in documents:

        metadata = document.get("metadata", {})

        results.append({
            "text": document.get("text", ""),
            "source": metadata.get("source", "Unknown"),
            "page": metadata.get("page", "Unknown"),
            "distance": document.get("distance"),
            "type": "vector"
        })

    return results


# --------------------------------------------------
# 3. KNOWLEDGE GRAPH SEARCH
# --------------------------------------------------

def graph_search(query, top_k=TOP_K_RESULTS):

    query_terms = extract_query_terms(query)

    if not query_terms:
        return {
            "entities": [],
            "relationships": []
        }

    matched_entities = set()
    relationship_matches = []

    financial_terms = {
        "revenue", "ebitda", "ebit", "profit",
        "profits", "margin", "margins",
        "earnings", "income", "expense",
        "expenses", "cash", "debt", "assets",
        "liabilities", "dividend", "capital",
        "growth", "sales", "valuation",
        "financial", "performance", "returns"
    }

    financial_query = bool(
        query_terms.intersection(financial_terms)
    )

    # Match entities.
    for entity_id, data in graph.nodes(data=True):

        name = data.get("name", "")
        description = data.get("description", "")

        entity_words = set(
            re.findall(
                r"[a-zA-Z0-9]+",
                f"{name} {description}".lower()
            )
        )

        if query_terms.intersection(entity_words):
            matched_entities.add(entity_id)

    # Match relationships.
    for source, target, edge_data in graph.edges(data=True):

        source_name = graph.nodes[source].get("name", "")
        target_name = graph.nodes[target].get("name", "")

        relationship = edge_data.get("relationship", "")
        evidence = edge_data.get("evidence", "")

        searchable_text = " ".join([
            source_name,
            target_name,
            relationship,
            evidence
        ]).lower()

        searchable_words = set(
            re.findall(r"[a-zA-Z0-9]+", searchable_text)
        )

        matched_terms = query_terms.intersection(searchable_words)

        if not matched_terms:
            continue

        evidence_words = set(
            re.findall(
                r"[a-zA-Z0-9]+",
                f"{relationship} {evidence}".lower()
            )
        )

        # Filter relationships unrelated to financial queries.
        if financial_query:

            financial_evidence = evidence_words.intersection(
                financial_terms
            )

            if not financial_evidence:
                continue

        source_words = set(
            re.findall(r"[a-zA-Z0-9]+", source_name.lower())
        )

        target_words = set(
            re.findall(r"[a-zA-Z0-9]+", target_name.lower())
        )

        score = len(matched_terms)

        score += 2 * len(
            query_terms.intersection(source_words)
        )

        score += 2 * len(
            query_terms.intersection(target_words)
        )

        relationship_matches.append({
            "source_id": source,
            "target_id": target,
            "source_name": source_name,
            "target_name": target_name,
            "relationship": relationship,
            "evidence": evidence,
            "source": edge_data.get("source_file", "Unknown"),
            "page": edge_data.get("page", "Unknown"),
            "score": score
        })

        matched_entities.add(source)
        matched_entities.add(target)

    relationship_matches.sort(
        key=lambda item: (
            -item["score"],
            item["source_name"],
            item["target_name"]
        )
    )

    relationship_matches = relationship_matches[:top_k]

    entity_results = []

    for entity_id in matched_entities:

        details = get_entity(entity_id)

        if details:
            entity_results.append(details)

    return {
        "entities": entity_results,
        "relationships": relationship_matches
    }


# --------------------------------------------------
# 4. RECIPROCAL RANK FUSION
# --------------------------------------------------

def reciprocal_rank_fusion(
    vector_results,
    graph_results,
    k=60
):

    combined = {}

    def add_result(item, rank, result_type):

        text = item.get(
            "text",
            item.get("evidence", "")
        ).strip()

        key = (
            item.get("source", "Unknown"),
            str(item.get("page", "Unknown")),
            text
        )

        if key not in combined:

            combined[key] = {
                "source": item.get("source", "Unknown"),
                "page": item.get("page", "Unknown"),
                "text": text,
                "rrf_score": 0.0,
                "retrieved_by": []
            }

        combined[key]["rrf_score"] += 1.0 / (k + rank)

        if result_type not in combined[key]["retrieved_by"]:
            combined[key]["retrieved_by"].append(result_type)

    # Vector results.
    for rank, item in enumerate(vector_results, start=1):
        add_result(item, rank, "vector")

    # Deduplicate graph evidence.
    unique_graph_evidence = []
    seen_graph_evidence = set()

    for item in graph_results.get("relationships", []):

        evidence_key = (
            item.get("source", "Unknown"),
            str(item.get("page", "Unknown")),
            item.get("evidence", "").strip()
        )

        if evidence_key in seen_graph_evidence:
            continue

        seen_graph_evidence.add(evidence_key)
        unique_graph_evidence.append(item)

    # Graph results.
    for rank, item in enumerate(unique_graph_evidence, start=1):
        add_result(item, rank, "graph")

    return sorted(
        combined.values(),
        key=lambda item: item["rrf_score"],
        reverse=True
    )


# --------------------------------------------------
# 5. HYBRID SEARCH
# --------------------------------------------------

def hybrid_search(query, top_k=TOP_K_RESULTS):

    vector_results = vector_search(query, top_k)

    graph_results = graph_search(query, top_k)

    fused_results = reciprocal_rank_fusion(
        vector_results,
        graph_results
    )

    return {
        "query": query,
        "vector_results": vector_results,
        "graph_results": graph_results,
        "fused_results": fused_results[:top_k]
    }


# --------------------------------------------------
# 6. BUILD HYBRID CONTEXT
# --------------------------------------------------

def build_hybrid_context(results):

    context_parts = []

    context_parts.append("DOCUMENT EVIDENCE:")

    for index, item in enumerate(
        results.get("vector_results", []),
        start=1
    ):

        context_parts.append(
            f"""
[Document Evidence {index}]
Source: {item['source']}
Page: {item['page']}
Content:
{item['text']}
"""
        )

    context_parts.append("\nKNOWLEDGE GRAPH EVIDENCE:")

    graph_results = results.get("graph_results", {})

    for index, relationship in enumerate(
        graph_results.get("relationships", []),
        start=1
    ):

        context_parts.append(
            f"""
[Graph Relationship {index}]
Entity 1: {relationship['source_name']}
Relationship: {relationship['relationship']}
Entity 2: {relationship['target_name']}
Evidence: {relationship['evidence']}
Source: {relationship['source']}
Page: {relationship['page']}
"""
        )

    context_parts.append("\nFUSED EVIDENCE RANKING:")

    for index, item in enumerate(
        results.get("fused_results", []),
        start=1
    ):

        context_parts.append(
            f"""
[Fused Evidence {index}]
Source: {item['source']}
Page: {item['page']}
RRF Score: {item['rrf_score']:.6f}
Retrieved By: {", ".join(item['retrieved_by'])}
Evidence:
{item['text']}
"""
        )

    context_parts.append("\nKNOWLEDGE GRAPH ENTITIES:")

    for entity in graph_results.get("entities", []):

        context_parts.append(
            f"""
Entity: {entity.get('name', 'Unknown')}
Type: {entity.get('entity_type', 'Unknown')}
Description: {entity.get('description', '')}
"""
        )

    return "\n".join(context_parts)


# --------------------------------------------------
# 7. PUBLIC FUNCTION FOR HYBRID RAG
# --------------------------------------------------

def run_hybrid_search(query, top_k=TOP_K_RESULTS):

    results = hybrid_search(query, top_k)

    context = build_hybrid_context(results)

    return results, context


# --------------------------------------------------
# 8. TESTING
# --------------------------------------------------

if __name__ == "__main__":

    query = "Reliance Retail strategic brand partnerships"

    print("\n" + "=" * 60)
    print("STOCKGRAPH AI - HYBRID RETRIEVAL")
    print("=" * 60)

    print(f"\nQuery: {query}")

    results, context = run_hybrid_search(query)

    print("\nVECTOR RESULTS:")
    print("Total:", len(results["vector_results"]))

    print("\nGRAPH RESULTS:")

    graph_results = results["graph_results"]

    print("Entities:", len(graph_results["entities"]))
    print("Relationships:", len(graph_results["relationships"]))

    print("\nFUSED RESULTS:")

    for item in results["fused_results"]:

        print(
            f"{item['source']} | Page {item['page']} | "
            f"Score: {item['rrf_score']:.6f} | "
            f"Methods: {', '.join(item['retrieved_by'])}"
        )

    print("\n" + "=" * 60)
    print("COMBINED RETRIEVAL CONTEXT")
    print("=" * 60)

    print(context)

    print("\n" + "=" * 60)
    print("HYBRID RETRIEVAL COMPLETED")
    print("=" * 60)
