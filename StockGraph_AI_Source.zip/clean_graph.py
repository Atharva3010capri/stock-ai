
from knowledge_graph import graph, load_graph, save_graph

print("Loading existing Knowledge Graph...")
load_graph()

before = graph.number_of_edges()
removed = 0

# Remove exact duplicate relationships while preserving distinct edges.
seen = set()
edges_to_remove = []

for source, target, key, data in graph.edges(keys=True, data=True):
    signature = (
        source,
        target,
        data.get("relationship", ""),
        data.get("source_file", ""),
        data.get("page", ""),
        data.get("evidence", "")
    )

    if signature in seen:
        edges_to_remove.append((source, target, key))
    else:
        seen.add(signature)

for source, target, key in edges_to_remove:
    graph.remove_edge(source, target, key)
    removed += 1

save_graph()

print("\nGRAPH CLEANUP COMPLETED")
print("Relationships before:", before)
print("Duplicate relationships removed:", removed)
print("Relationships after:", graph.number_of_edges())
print("Entities preserved:", graph.number_of_nodes())
