

from pathlib import Path
from pypdf import PdfReader
import hashlib


def extract_pdf(pdf_path):
    """Extract text from each PDF page."""

    pdf_path = Path(pdf_path)

    if not pdf_path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    if pdf_path.suffix.lower() != ".pdf":
        raise ValueError("Only PDF files are supported.")

    reader = PdfReader(str(pdf_path))
    extracted_pages = []

    for page_number, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""

        if text.strip():
            extracted_pages.append({
                "text": text.strip(),
                "source": pdf_path.name,
                "page": page_number
            })

    if not extracted_pages:
        raise ValueError(
            "No readable text found in PDF. "
            "It may be scanned or image-based."
        )

    return extracted_pages


def chunk_text(pages, chunk_size=1000, overlap=200):
    """Split PDF text into overlapping chunks."""

    if chunk_size <= 0:
        raise ValueError("Chunk size must be positive.")

    if overlap < 0 or overlap >= chunk_size:
        raise ValueError("Invalid overlap value.")

    chunks = []
    step = chunk_size - overlap

    for page_data in pages:
        text = page_data["text"]

        for start in range(0, len(text), step):
            chunk = text[start:start + chunk_size].strip()

            if not chunk:
                continue

            unique_text = (
                f"{page_data['source']}_"
                f"{page_data['page']}_{start}"
            )

            chunk_id = hashlib.sha256(
                unique_text.encode("utf-8")
            ).hexdigest()

            chunks.append({
                "id": chunk_id,
                "text": chunk,
                "metadata": {
                    "source": page_data["source"],
                    "page": page_data["page"]
                }
            })

            if start + chunk_size >= len(text):
                break

    return chunks


def process_pdf(pdf_path):
    """Complete PDF extraction and chunking pipeline."""

    pages = extract_pdf(pdf_path)

    chunks = chunk_text(
        pages,
        chunk_size=1000,
        overlap=200
    )

    return chunks


if __name__ == "__main__":
    print("StockGraph AI PDF ingestion module loaded successfully.")
