import os
import chromadb
import networkx as nx
from config import CHROMA_DIR, GRAPH_DIR

def inspect_chroma():
    print("--- ChromaDB Inspection ---")
    if not os.path.exists(CHROMA_DIR):
        print(f"Chroma directory '{CHROMA_DIR}' not found.")
        return
    
    client = chromadb.PersistentClient(path=CHROMA_DIR)
    collections = client.list_collections()
    
    if not collections:
        print("No collections found in ChromaDB.")
        return

    for col in collections:
        count = col.count()
        print(f"Collection Name: {col.name} | Total Indexed Chunks: {count}")

def inspect_graph():
    print("\n--- Knowledge Graph Inspection ---")
    graph_files = [f for f in os.path.join(GRAPH_DIR, "") if f.endswith(".graphml") or os.path.exists(os.path.join(GRAPH_DIR, "graph.graphml"))]
    
    # Check default graph file path used previously
    filepath = os.path.join(GRAPH_DIR, "graph.graphml")
    if not os.path.exists(filepath):
        print(f"Knowledge graph file not found at {filepath}.")
        return

    graph = nx.read_graphml(filepath)
    print(f"Graph File Loaded: {filepath}")
    print(f"Total Entities (Nodes): {graph.number_of_nodes()}")
    print(f"Total Relationships (Edges): {graph.number_of_edges()}")
    
    print("\nSample Nodes (Entities):")
    for node in list(graph.nodes())[:10]:
        print(f" - {node}")
        
    print("\nSample Edges (Relationships):")
    for u, v, data in list(graph.edges(data=True))[:10]:
        print(f" - {u} --[{data.get('relation', 'CONNECTED_TO')}]--> {v}")

if __name__ == "__main__":
    inspect_chroma()
    inspect_graph()