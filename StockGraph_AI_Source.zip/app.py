
import json
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st
import yfinance as yf

from config import DATA_DIR, TOP_K_RESULTS
import knowledge_graph as kg
from hybrid_rag import answer_question
from ingest import process_pdf
from vector_store import store_chunks, get_document_count


# --------------------------------------------------
# PAGE CONFIGURATION
# --------------------------------------------------

st.set_page_config(
    page_title="StockGraph AI",
    page_icon="📈",
    layout="wide"
)

st.title("📈 StockGraph AI")
st.caption(
    "Financial research powered by market data, "
    "Ollama, ChromaDB, and Knowledge Graph intelligence."
)


# --------------------------------------------------
# HELPER FUNCTIONS
# --------------------------------------------------

def format_number(value, decimals=2):
    if value is None:
        return "N/A"

    try:
        if pd.isna(value):
            return "N/A"
        return f"{float(value):,.{decimals}f}"
    except (ValueError, TypeError):
        return "N/A"


def calculate_rsi(series, period=14):
    delta = series.diff()

    gains = delta.clip(lower=0)
    losses = -delta.clip(upper=0)

    average_gain = gains.rolling(period).mean()
    average_loss = losses.rolling(period).mean()

    relative_strength = average_gain / average_loss.replace(0, float("nan"))
    return 100 - (100 / (1 + relative_strength))


# --------------------------------------------------
# SIDEBAR
# --------------------------------------------------

st.sidebar.title("Research Controls")

ticker_input = st.sidebar.text_input(
    "Stock ticker",
    value="AAPL",
    help="Examples: AAPL, MSFT, RELIANCE.NS, TCS.NS"
).strip().upper()

st.sidebar.caption(
    "Indian stocks generally use .NS or .BO suffixes. "
    "US stocks generally use their standard ticker."
)

st.sidebar.divider()

st.sidebar.subheader("Upload Financial Report")

uploaded_file = st.sidebar.file_uploader(
    "Upload an annual report or financial PDF",
    type=["pdf"]
)

company_name = st.sidebar.text_input(
    "Company name",
    value=""
)

if st.sidebar.button(
    "Ingest PDF",
    disabled=uploaded_file is None
):
    try:
        safe_filename = Path(uploaded_file.name).name
        file_path = DATA_DIR / safe_filename

        with open(file_path, "wb") as file:
            file.write(uploaded_file.getbuffer())

        with st.spinner("Extracting and embedding PDF content..."):
            chunks = process_pdf(file_path)

            # Add company and ticker metadata to each chunk.
            for chunk in chunks:
                chunk["metadata"]["company"] = company_name.strip()
                chunk["metadata"]["ticker"] = ticker_input

            stored_count = store_chunks(chunks)

        st.sidebar.success(
            f"Successfully stored {stored_count} chunks."
        )

    except Exception as error:
        st.sidebar.error(f"PDF ingestion failed: {error}")


try:
    document_count = get_document_count()
    st.sidebar.metric("Indexed document chunks", document_count)
except Exception:
    st.sidebar.warning("Could not read document count.")


# --------------------------------------------------
# MAIN DASHBOARD
# --------------------------------------------------

if not ticker_input:
    st.info("Enter a valid stock ticker in the sidebar.")
    st.stop()


tab1, tab2, tab3, tab4 = st.tabs([
    "Market & Fundamentals",
    "Technical Analysis",
    "Knowledge Graph",
    "AI Financial Research"
])


# --------------------------------------------------
# TAB 1: MARKET AND FUNDAMENTALS
# --------------------------------------------------

with tab1:
    st.subheader(f"Market Overview: {ticker_input}")

    try:
        stock = yf.Ticker(ticker_input)

        with st.spinner("Loading market data..."):
            history = stock.history(period="6mo")

            try:
                info = stock.info or {}
            except Exception:
                info = {}

        if history.empty:
            st.error(
                f"No market data found for {ticker_input}. "
                "Check the ticker symbol."
            )
        else:
            current_price = float(history["Close"].iloc[-1])

            previous_close = info.get("previousClose")

            if previous_close is None and len(history) > 1:
                previous_close = float(history["Close"].iloc[-2])

            currency = info.get("currency", "Currency unavailable")

            company_title = info.get("longName", ticker_input)

            st.markdown(f"### {company_title}")

            col1, col2, col3, col4 = st.columns(4)

            col1.metric(
                "Latest Price",
                f"{currency} {format_number(current_price)}"
            )

            col2.metric(
                "Previous Close",
                format_number(previous_close)
            )

            col3.metric(
                "P/E Ratio",
                format_number(info.get("trailingPE"))
            )

            market_cap = info.get("marketCap")

            col4.metric(
                "Market Capitalization",
                (
                    f"{market_cap:,.0f}"
                    if isinstance(market_cap, (int, float))
                    else "N/A"
                )
            )

            st.divider()

            col5, col6, col7, col8 = st.columns(4)

            col5.metric(
                "EPS",
                format_number(info.get("trailingEps"))
            )

            col6.metric(
                "Price to Book",
                format_number(info.get("priceToBook"))
            )

            col7.metric(
                "Dividend Yield",
                (
                    f"{info['dividendYield'] * 100:.2f}%"
                    if isinstance(info.get("dividendYield"), (int, float))
                    else "N/A"
                )
            )

            col8.metric(
                "52-Week High",
                format_number(info.get("fiftyTwoWeekHigh"))
            )

            st.caption(
                f"Sector: {info.get('sector', 'N/A')} | "
                f"Industry: {info.get('industry', 'N/A')}"
            )

            def format_percent(value):
                try:
                    number = float(value)
                    if not pd.notna(number):
                        return "N/A"
                    return f"{number * 100:.2f}%"
                except (TypeError, ValueError):
                    return "N/A"

            st.divider()
            st.markdown("### Profitability and Growth")

            col9, col10, col11, col12 = st.columns(4)
            col9.metric("Return on Equity (ROE)", format_percent(info.get("returnOnEquity")))
            col10.metric("Return on Assets (ROA)", format_percent(info.get("returnOnAssets")))
            col11.metric("Net Profit Margin", format_percent(info.get("profitMargins")))
            col12.metric("Operating Margin", format_percent(info.get("operatingMargins")))

            col13, col14, col15 = st.columns(3)
            col13.metric("Revenue Growth", format_percent(info.get("revenueGrowth")))
            col14.metric("Earnings Growth", format_percent(info.get("earningsGrowth")))
            col15.metric("Gross Margin", format_percent(info.get("grossMargins")))

            st.markdown("### Debt and Liquidity")

            debt_value = info.get("debtToEquity")
            try:
                debt_display = (
                    f"{float(debt_value):.2f}%"
                    if pd.notna(debt_value) else "N/A"
                )
            except (TypeError, ValueError):
                debt_display = "N/A"

            col16, col17, col18 = st.columns(3)
            col16.metric("Debt-to-Equity", debt_display)
            col17.metric("Current Ratio", format_number(info.get("currentRatio")))
            col18.metric("Quick Ratio", format_number(info.get("quickRatio")))

            st.markdown("### Additional Valuation")

            trailing_pe = info.get("trailingPE")
            try:
                earnings_yield = (
                    f"{100 / float(trailing_pe):.2f}%"
                    if float(trailing_pe) > 0 else "N/A"
                )
            except (TypeError, ValueError, ZeroDivisionError):
                earnings_yield = "N/A"

            col19, col20, col21 = st.columns(3)
            col19.metric("Earnings Yield", earnings_yield)
            col20.metric("Forward P/E", format_number(info.get("forwardPE")))
            col21.metric(
                "Price-to-Sales",
                format_number(info.get("priceToSalesTrailing12Months"))
            )


            st.warning(
                "Market information is supplied by Yahoo Finance. "
                "Availability, delays, and data quality may vary."
            )

    except Exception as error:
        st.error(f"Market data error: {error}")


# --------------------------------------------------
# TAB 2: TECHNICAL ANALYSIS
# --------------------------------------------------

with tab2:
    st.subheader("Technical Analysis")

    try:
        stock = yf.Ticker(ticker_input)
        history = stock.history(period="6mo")

        if history.empty:
            st.warning("No historical price data available.")
        else:
            history["SMA 20"] = history["Close"].rolling(20).mean()
            history["SMA 50"] = history["Close"].rolling(50).mean()
            history["RSI 14"] = calculate_rsi(history["Close"])

            price_chart = px.line(
                history,
                y=["Close", "SMA 20", "SMA 50"],
                title=f"{ticker_input} — Price and Moving Averages"
            )

            st.plotly_chart(
                price_chart,
                use_container_width=True
            )

            rsi_chart = px.line(
                history,
                y="RSI 14",
                title="Relative Strength Index (14)"
            )

            rsi_chart.add_hline(y=70, line_dash="dash")
            rsi_chart.add_hline(y=30, line_dash="dash")

            st.plotly_chart(
                rsi_chart,
                use_container_width=True
            )

            latest_rsi = history["RSI 14"].dropna()

            if not latest_rsi.empty:
                st.metric(
                    "Latest RSI (14)",
                    format_number(latest_rsi.iloc[-1])
                )

            st.caption(
                "SMA and RSI are technical indicators, not standalone "
                "buy or sell signals."
            )

    except Exception as error:
        st.error(f"Technical analysis error: {error}")


# --------------------------------------------------
# TAB 3: KNOWLEDGE GRAPH
# --------------------------------------------------

with tab3:
    st.subheader("Knowledge Graph Intelligence")

    try:
        statistics = kg.get_graph_statistics()

        col1, col2 = st.columns(2)

        col1.metric(
            "Entities",
            statistics.get("total_entities", 0)
        )

        col2.metric(
            "Relationships",
            statistics.get("total_relationships", 0)
        )

        st.write("### Search Entities")

        graph_keyword = st.text_input(
            "Search by company, ticker, or entity",
            value=ticker_input,
            key="graph_search"
        )

        entities = kg.search_entities(graph_keyword)

        if entities:
            st.dataframe(
                pd.DataFrame(entities),
                use_container_width=True,
                hide_index=True
            )

            # Show graph relationships connected to matched entities.
            matched_ids = {
                str(entity.get("entity_id", entity.get("id", "")))
                for entity in entities
            }

            matched_ids.discard("")

            relationship_rows = []

            for source, target, key, attributes in kg.graph.edges(
                keys=True,
                data=True
            ):
                if (
                    str(source) in matched_ids
                    or str(target) in matched_ids
                ):
                    relationship_rows.append({
                        "Source": str(source),
                        "Relationship": attributes.get(
                            "relationship",
                            attributes.get("relation", key)
                        ),
                        "Target": str(target)
                    })

            if relationship_rows:
                st.write("### Connected Relationships")

                st.dataframe(
                    pd.DataFrame(relationship_rows),
                    use_container_width=True,
                    hide_index=True
                )
            else:
                st.info(
                    "No relationships were found for these matching entities."
                )

        else:
            st.info(
                "No matching entities found in the existing Knowledge Graph."
            )

    except Exception as error:
        st.error(f"Knowledge Graph error: {error}")


# --------------------------------------------------
# --------------------------------------------------
# TAB 4: AI FINANCIAL RESEARCH
# --------------------------------------------------

with tab4:
    st.subheader("AI Financial Analyst")

    st.write(
        "Ask questions about companies, financial performance, "
        "annual reports, and retrieved financial evidence."
    )

    question = st.text_area(
        "Enter your research question",
        value=(
            f"What are the key financial highlights, "
            f"performance trends, and risks for {ticker_input}?"
        ),
        height=120
    )

    if st.button("Generate AI Research", type="primary"):
        if not question.strip():
            st.warning("Enter a research question first.")
        else:
            try:
                with st.spinner(
                    "Searching financial evidence and generating analysis..."
                ):
                    result = answer_question(
                        question,
                        top_k=TOP_K_RESULTS,
                        ticker=ticker_input
                    )

                st.write("### AI Research Answer")
                st.markdown(result.get("answer", "No answer generated."))

                st.divider()
                st.write("### Retrieved Sources")

                sources = result.get("sources", [])

                if sources:
                    for source, page in sources:
                        st.write(f"- **{source}** - Page {page}")
                else:
                    st.info("No source citations were returned.")

                st.write("### Citation Validation")

                citation_report = result.get("citation_report", {})

                if citation_report:
                    st.json(citation_report)
                else:
                    st.info("No citation validation report available.")

                st.caption(
                    "Citation validation checks whether cited source/page "
                    "pairs were retrieved. It does not independently prove "
                    "that every claim is semantically supported."
                )

            except Exception as error:
                st.error(f"AI research failed: {error}")


# FOOTER
# --------------------------------------------------

st.divider()

st.caption(
    "StockGraph AI | Research and educational use. "
    "Not investment advice."
)
