
import re
import ollama

from config import OLLAMA_BASE_URL, LLM_MODEL, TOP_K_RESULTS
from ingest import process_pdf
from vector_store import store_chunks, search_documents


# --------------------------------------------------
# OLLAMA CLIENT
# --------------------------------------------------

client = ollama.Client(host=OLLAMA_BASE_URL)


# --------------------------------------------------
# PDF INGESTION
# --------------------------------------------------

def ingest_document(pdf_path):
    """
    Extract text from a PDF, split it into chunks,
    generate embeddings and store them in ChromaDB.
    """

    print(f"Processing PDF: {pdf_path}")

    chunks = process_pdf(pdf_path)

    if not chunks:
        raise ValueError(
            "No text chunks were extracted from the PDF."
        )

    stored_count = store_chunks(chunks)

    print(
        f"Successfully indexed {stored_count} chunks."
    )

    return stored_count


# --------------------------------------------------
# CITATION VALIDATION
# --------------------------------------------------

def validate_citations(answer, allowed_citations):
    """
    Ensure every generated citation refers to a
    source-page pair included in the retrieved context.

    This validates citation references, not whether
    the cited passage actually supports each claim.
    """

    citations = re.findall(
        r"\(Source:\s*([^,]+),\s*Page:\s*(\d+)\)",
        answer
    )

    invalid_citations = []

    for filename, page in citations:

        citation = (
            f"{filename.strip()}, Page {page}"
        )

        if citation not in allowed_citations:
            invalid_citations.append(citation)

    if invalid_citations:
        return False, invalid_citations

    return True, []


# --------------------------------------------------
# RAG QUESTION ANSWERING
# --------------------------------------------------

def answer_question(question, top_k=TOP_K_RESULTS):
    """
    Retrieve relevant document chunks and generate
    an evidence-based answer using the Ollama model.
    """

    if not question or not question.strip():
        return "Please enter a valid question."

    # STEP 1: Retrieve relevant documents

    results = search_documents(
        question,
        top_k=top_k
    )

    if not results:
        return (
            "No relevant documents were found. "
            "Please upload and index a financial PDF first."
        )

    # STEP 2: Prepare context and allowed citations

    context_parts = []
    allowed_citations = []

    for result in results:

        metadata = result["metadata"]

        source = metadata.get(
            "source",
            "Unknown source"
        )

        page = metadata.get(
            "page",
            "Unknown page"
        )

        citation = f"{source}, Page {page}"

        if citation not in allowed_citations:
            allowed_citations.append(citation)

        context_parts.append(
            f"[SOURCE: {citation}]\n"
            f"{result['text']}"
        )

    context = "\n\n".join(context_parts)

    allowed_citation_list = "\n".join(
        f"- {citation}"
        for citation in allowed_citations
    )

    # STEP 3: Construct strict RAG prompt

    prompt = f"""
You are StockGraph AI, a financial document research assistant.

Your task is to answer the user's question using ONLY
the retrieved document passages provided below.

STRICT RULES:

1. Use only information explicitly supported by the context.
2. Never invent financial figures, company activities,
   business relationships, dates or facts.
3. Never use outside knowledge to fill missing information.
4. Every factual statement must have a source citation.
5. Cite only source-page combinations from the
   ALLOWED CITATIONS list.
6. If the retrieved passages do not answer the question,
   clearly say that the available evidence is insufficient.
7. Do not present a partial description as a complete
   description of the company.
8. Distinguish document facts from your own interpretation.
9. Do not provide personalized investment advice.
10. Do not invent citations.

ALLOWED CITATIONS:

{allowed_citation_list}

RETRIEVED DOCUMENT CONTEXT:

{context}

USER QUESTION:

{question}

ANSWER FORMAT:

- Give a direct answer.
- Use numbered points when useful.
- Include relevant financial figures only when present.
- Add citations immediately after factual claims.
- Mention limitations in the retrieved evidence.
- Do not cite any page outside the allowed list.

Citation format:

(Source: filename, Page: number)
"""

    # STEP 4: Generate answer using Ollama

    try:

        response = client.generate(
            model=LLM_MODEL,
            prompt=prompt,
            options={
                "temperature": 0
            }
        )

        answer = response["response"].strip()

    except Exception as error:

        return (
            "Ollama generation failed.\n"
            f"Error: {str(error)}"
        )

    # STEP 5: Validate generated citations

    is_valid, invalid_citations = validate_citations(
        answer,
        allowed_citations
    )

    if not is_valid:

        return (
            "WARNING: The AI generated unsupported citations.\n\n"
            f"Invalid citations: {invalid_citations}\n\n"
            "Please retry with a narrower question."
        )

    # STEP 6: Return final answer

    if not answer:
        return "The AI returned an empty response."

    return answer


# --------------------------------------------------
# DIRECT EXECUTION TEST
# --------------------------------------------------

if __name__ == "__main__":

    print("=" * 55)
    print("STOCKGRAPH AI - RAG PIPELINE")
    print("=" * 55)

    print("Ollama model:", LLM_MODEL)

    print("\nRAG pipeline initialized successfully.")

    print(
        "PDF ingestion, semantic retrieval, "
        "answer generation and citation validation are ready."
    )
